import numpy as np
import pandas as pd

s = [ 1, 2, 3, 4, 3, 6, 3, 8, 3, 10 ]
n = int(input('введите число '))
k=0
for i in range(0,len(s)):
    if s[i]==n:
        k+=1
print (k)