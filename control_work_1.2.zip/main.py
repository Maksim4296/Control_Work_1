import numpy as np
import pandas as pd

s = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
for i in range(0,len(s)):
    del s[3*i]
    s[5*i] = s[5*i]*2
print (s)