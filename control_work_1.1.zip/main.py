import numpy as np
import pandas as pd

s = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
n = int(input('введите число'))

for i in range(0, len(s)):
    if n%s[i]!=0:
        del s[i]
print (s)